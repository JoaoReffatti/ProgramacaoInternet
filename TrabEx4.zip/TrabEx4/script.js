let InputSalario = document.querySelector("#Salario");
let InputCodigo = document.querySelector("#Codigo");
let btSalario = document.querySelector("#btSalario");
let ResultadoSalario = document.querySelector("#ResultadoSalario");

function calcularSalario() {
    let Salario = Number(InputSalario.value);
    let Codigo = Number(InputCodigo.value);
       
    if (Salario > 0) {
        let aumento = 0;
        let cargo = "";

        if (Codigo === 101) {
            aumento = 0.10;
            cargo = "Gerente";
        } else if (Codigo === 102) {
            aumento = 0.20;
            cargo = "Engenheiro";
        } else if (Codigo === 103) {
            aumento = 0.30;
            cargo = "Técnico";
        } else {
            aumento = 0.40;
            cargo = "Cargo não listado";
        }

        let novoSalario = Salario * (1 + aumento);
        let diferenca = novoSalario - Salario;

        ResultadoSalario.innerHTML = `
        Cargo: ${cargo}<br>
        Salário antigo: R$ ${Salario}<br>
        Novo salário: R$ ${novoSalario}<br>
        Aumento: R$ ${diferenca} (${(aumento * 100)}%)`;
    } else {
        ResultadoSalario.innerHTML = "Por favor, insira um sálario válido.";
    }
}

btSalario.onclick = function () {
    calcularSalario();
};