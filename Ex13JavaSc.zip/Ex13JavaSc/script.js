let Inputpreco = document.querySelector("#preco");
let Inputvalor = document.querySelector("#valor");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function Calcularlitros(){
    let preco = Number(Inputpreco.value);
    let valor = Number(Inputvalor.value);

    if (preco > 0){
        let litros = preco / valor;
        resultado.innerHTML = "Você conseguiu colocar " + litros + " litros de gasolina!";
    }
    else {
        resultado.innerHTML = "Por favor, informe um valor válido!";
    }
  
}
btCalcular.onclick = function(){
    Calcularlitros();
}
