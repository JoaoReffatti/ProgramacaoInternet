let inputSaldo = document.querySelector("#saldoMedio");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultadoCredito");

function calcularCredito() {
    let saldo = Number(inputSaldo.value);
    let percentual = 0;
    let mensagem = "";

    if (saldo <= 0) {
        resultado.innerHTML = "Por favor, insira um saldo válido.";
        return;
    }

    if (saldo <= 200) {
        percentual = 0;
        mensagem = "Nenhum crédito concedido.";
    } else if (saldo <= 400) {
        percentual = 0.20;
    } else if (saldo <= 600) {
        percentual = 0.30;
    } else {
        percentual = 0.40;
    }

    if (percentual > 0) {
        let credito = saldo * percentual;
        mensagem = `Saldo médio: R$ ${saldo.toFixed(2).replace('.', ',')}<br>
                    Crédito concedido: R$ ${credito.toFixed(2).replace('.', ',')} (${percentual * 100}%)`;
    }

    resultado.innerHTML = mensagem;
}

botao.onclick = calcularCredito;