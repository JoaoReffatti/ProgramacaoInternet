let inputValorQuilo = document.querySelector("#ValorQuilo");
let inputQuantidadeQuilo = document.querySelector("#QuantidadeQuilo");
let btValor = document.querySelector("#btCalcularValor");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularValor(){

    let ValorQuilo = Number(inputValorQuilo.value);
    let QuantidadeQuilo = Number(inputQuantidadeQuilo.value);
    let Valor = ValorQuilo * QuantidadeQuilo;

    h3Resultado.textContent = (ValorQuilo * QuantidadeQuilo);
}
btValor.onclick = function(){
    CalcularValor();
}