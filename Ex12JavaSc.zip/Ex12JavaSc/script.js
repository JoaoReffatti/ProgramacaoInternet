let Inputnome = document.querySelector("#nome");
let Inputidade = document.querySelector("#idade");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function DiasDeVida(){
    let nome = Inputnome.value;
    let idade = Number(Inputidade.value);

    let diasVividos = idade * 365;
    
    resultado.innerHTML = nome + ", você já viveu : " + diasVividos + " Dias";
    

}
btCalcular.onclick = function(){
    DiasDeVida();

}