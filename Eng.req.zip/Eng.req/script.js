let btXp = document.querySelector("#btXp");
let btFdd = document.querySelector("#btFdd");
let btKanban = document.querySelector("#btKanban");
let btCrystal = document.querySelector("#btCrystal");
let btMsf = document.querySelector("#btMsf");


let resultadoxp = document.querySelector("#resultadoxp");
let resultadofdd = document.querySelector("#resultadofdd");
let resultadokanban = document.querySelector("#resultadokanban");
let resultadocrystal = document.querySelector("#resultadocrystal");
let resultadomsf = document.querySelector("#resultadomsf");

//funções e resultados exibidos

function limparResultados() {
    resultadoxp.innerText = "";
    resultadofdd.innerText = "";
    resultadokanban.innerText = "";
    resultadocrystal.innerText = "";
    resultadomsf.innerText = ""; // corrigido aqui
}

function extreme() {
    const estaVazio = resultadoxp.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadoxp.innerText = "XP (Extreme Programming) é uma metodologia ágil focada em melhorar a qualidade do software e a capacidade de resposta às mudanças.";
    }
}

function feature() {
    const estaVazio = resultadofdd.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadofdd.innerText = "FDD (Feature-Driven Development) é uma metodologia ágil centrada no desenvolvimento por funcionalidades.";
    }
}

function kanban() {
    const estaVazio = resultadokanban.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadokanban.innerText = "Kanban é uma metodologia visual para gerenciamento de tarefas e fluxo de trabalho.";
    }
}

function crystal() {
    const estaVazio = resultadocrystal.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadocrystal.innerText = "Crystal é uma família de metodologias ágeis que se adapta ao tamanho e criticidade do projeto.";
    }
}

function msf() {
    const estaVazio = resultadomsf.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadomsf.innerText = "MSF (Microsoft Solutions Framework) é uma metodologia de entrega de soluções baseada em práticas comprovadas.";
    }
}


//botões

btXp.onclick = function(){
    extreme();
}
btFdd.onclick = function(){
    feature();
}
btKanban.onclick = function(){
    kanban();
}
btCrystal.onclick = function(){
    crystal();
}
btMsf.onclick = function(){
    msf();
}