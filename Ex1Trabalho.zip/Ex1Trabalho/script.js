let InputLadoX = document.querySelector("#LadoX");
let InputLadoY = document.querySelector("#LadoY");
let InputLadoZ = document.querySelector("#LadoZ");
let btVerificar = document.querySelector("#btVerificar");
let ResultadoTriangulo = document.querySelector("#ResultadoTriangulo");

function verificarTriangulo() {
    let LadoX = Number(InputLadoX.value);
    let LadoY = Number(InputLadoY.value);
    let LadoZ = Number(InputLadoZ.value);

    //VERIFICAR SE OS LADOS FORMAM UM TRIANGULO
    if (LadoX < LadoY + LadoZ && LadoY < LadoX + LadoZ && LadoZ < LadoX + LadoY) {
        if (LadoX === LadoY && LadoY === LadoZ) {
            ResultadoTriangulo.innerHTML = " Triângulo Equilátero: Todos os lados iguais.";
        }
        else if (LadoX === LadoY || LadoX === LadoZ || LadoY === LadoZ) {
            ResultadoTriangulo.innerHTML = " Triângulo Isósceles: Dois lados iguais.";
        }
        else {
            ResultadoTriangulo.innerHTML = " Triângulo Escaleno: Todos os lados diferentes.";
        }
    }    
        else {
            ResultadoTriangulo.innerHTML = " Os valores informados não formam um triângulo.";
        }

        
    
}

btVerificar.onclick = function () {
    verificarTriangulo();
}