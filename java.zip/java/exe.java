import java.util.Scanner;

public class exe{
    public static void main(String []args){
        int cont;
        cont = 0;

        System.out.println("Exemplo enquanto (while)");

        while (cont < 5){
            System.out.println("Contador " + cont);
            //cont++;
            cont++;
        }

        System.out.println("Exemplo repita (do)");
        cont = 0;

        do{
            System.out.println("Contador " + cont);
            cont++;
        } while (cont < 5);

        System.out.println("Exemplo com para (for)");

        for (int i=0; i < 5; i++){
            System.out.println("Contador " + i);
            
        }
    }
}

