import java.util.Scanner;

public class lista2ex9 {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);

        Double valor;
        int codigo;

        System.out.println("Informe o valor total da compra: ");
        valor = s.nextDouble();
        System.out.println("1 = A vista com 10% de desconto ");
        System.out.println("2 = A prazo, 1x com 8% de desconto ");
        System.out.println("3 = A prazo, 5x sem descontos ou acrescimos ");
        System.out.println("4 = A prazo, 10x com acrescimo de 5% no valor total ");
        System.out.println("Informe o codigo da condição de pagamento (1 ao 4): ");
        codigo = s.nextInt();

        Double valorFinal;
        int parcelas;
        Double valorParcela;

        switch (codigo) {
            case 1:
            valorFinal = valor * 0.90; //10% de desconto
            parcelas = 1;
            break;

            case 2:
            valorFinal = valor * 0.92; //8% de desconto
            parcelas = 1;
            break;

            case 3:
            valorFinal = valor;
            parcelas = 5;
            break;

            case 4:
            valorFinal = valor * 1.05; //5% de acrescimo
            parcelas = 10;
            break;
            default:
            System.out.println("Codigo invalido! ");
            return;
        }

        valorParcela = valorFinal / parcelas;
        

        //Saida dos resultados
        

        System.out.println("Resumo da compra: ");
        System.out.println("Valor total a ser pago: " + valorFinal);
        System.out.println("Quantidade de parcelas: " + parcelas);
        System.out.println("Desconto dado: " + (valor - valorFinal));
        System.out.println("Valor de cada parcela: " + valorParcela);


    }
}
