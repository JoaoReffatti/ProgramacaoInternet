import java.util.Scanner;

public class lista2ex7{
   
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);

        int mes;
        String resultado = "";
    
        System.out.println("Informe o mes em formato numerico: ");
        mes = s.nextInt();

        if(mes < 1 || mes > 12) {
        resultado = "Mes invalido";
        } else if (mes == 9) {
            resultado = "Mes atual";
        } else if (mes > 9) {
            resultado = "Mes futuro";
        } else {
            resultado = "Mes passado";
        }

        System.out.println(resultado);
        
    }
}
