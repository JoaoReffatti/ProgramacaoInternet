let Inputlargura = document.querySelector("#largura");
let Inputcomprimento = document.querySelector("#largura");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularArea() {
    let largura = Number(Inputlargura.value);
    let comprimento = Number(Inputcomprimento.value);
    let area = largura * comprimento;

    h3Resultado.innerHTML = "A área do terreno é: " + area + "m²";

}
btCalcular.onclick = function() {
    CalcularArea();
}