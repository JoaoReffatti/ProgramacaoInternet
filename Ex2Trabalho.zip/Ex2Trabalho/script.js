let inputPeso = document.querySelector("#Peso");
let inputAltura = document.querySelector("#Altura");
let btImc = document.querySelector("#btImc");
let ResultadoIMC = document.querySelector("#ResultadoIMC");

function calcularIMC() {
    let Peso = Number(inputPeso.value);
    let Altura = Number(inputAltura.value);

    if (Peso > 0 && Altura > 0){
        let imc = Peso / (Altura * Altura);
        let classificacao = "";
        
        if (imc < 18.5) {
            classificacao = "Abaixo do peso.";
        } else if (imc < 25) {
            classificacao = "Peso normal.";
        } else if (imc < 30) {
            classificacao = "Sobrepeso.";
        } else if (imc < 35) {
            classificacao = "Obesidade grau 1.";
        } else if (imc < 40) {
            classificacao = "Obesidade grau 2.";
        } else {
            classificacao = "Obesidade grau 3.";
        }

        ResultadoIMC.innerHTML = `Seu IMC é <strong>${imc.toFixed(2)}</strong> = ${classificacao}`;
        
    }
    else {
        ResultadoIMC.innerHTML = "Por favor, insira valores válidos de peso e altura.";
    }
}
btImc.onclick = function () {
    calcularIMC();
}