let btXp = document.querySelector("#btXp");
let btFdd = document.querySelector("#btFdd");
let btKanban = document.querySelector("#btKanban");
let btCrystal = document.querySelector("#btCrystal");
let btMsf = document.querySelector("#btMsf");
let btNome = document.querySelector("#btNome");


let resultadoxp = document.querySelector("#resultadoxp");
let resultadofdd = document.querySelector("#resultadofdd");
let resultadokanban = document.querySelector("#resultadokanban");
let resultadocrystal = document.querySelector("#resultadocrystal");
let resultadomsf = document.querySelector("#resultadomsf");
let resultadonome = document.querySelector("#resultadonome");

//funções e resultados exibidos

function limparResultados() {
    resultadoxp.innerText = "";
    resultadofdd.innerText = "";
    resultadokanban.innerText = "";
    resultadocrystal.innerText = "";
    resultadomsf.innerText = ""; // corrigido aqui
}

function extreme() {
    const estaVazio = resultadoxp.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadoxp.innerText = `Extreme Programming (XP)

O Extreme Programming (XP) é uma metodologia ágil criada no final dos anos 90 para desenvolver software de alta qualidade, com foco em feedback rápido, proximidade com o cliente e entregas curtas. Diferente dos métodos tradicionais, que são rígidos e cheios de etapas, o XP é flexível e adaptável, acompanhando as constantes mudanças das necessidades do cliente.

Componentes humanos envolvidos:
No Extreme Programming (XP), cada papel tem funções bem definidas. O Cliente diz o que precisa ser feito, prioriza as tarefas e realiza os feedbacks. Os Programadores trabalham em duplas, criam testes e mantêm contato direto com o cliente. O Coach orienta a equipe para seguir as práticas do XP e melhorar sempre. Os Testadores ajudam a criar testes de aceitação e verificam se tudo funciona. O Tracker acompanha prazos e o ritmo do time. Já o Gerente cuida da parte logística e de contratos, sem interferir no trabalho técnico dos programadores.

Fases do processo:
No XP, o processo segue algumas etapas principais. Na Exploração, cliente e equipe criam histórias de usuário para entender necessidades. No Planejamento do Release, o projeto é dividido em partes com entregas e prazos. As Iterações duram de 1 a 2 semanas, com desenvolvimento das histórias usando TDD, integração contínua, refatoração e programação em pares. Os Testes de aceitação confirmam se o software atende ao que o cliente pediu. Por fim, em cada iteração há pequenas entregas, que fornecem uma versão funcional para feedback imediato.

Vantagens e desvantagens:
O Extreme Programming (XP) apresenta vantagens e desvantagens que precisam ser consideradas. Entre as vantagens, destaca-se a capacidade de adaptação rápida a mudanças, a entrega frequente de resultados, o aumento da qualidade do código por meio de testes e refatoração, a colaboração intensa entre equipe e cliente e a redução de riscos graças ao feedback constante. Por outro lado, há também desvantagens: o método depende da presença contínua do cliente, tende a gerar pouca documentação, exige uma equipe madura e experiente, pode levar à perda da visão geral do projeto quando há foco excessivo no curto prazo e ainda impõe pressão por prazos curtos, o que pode causar estresse na equipe.`;
    }
}

function feature() {
    const estaVazio = resultadofdd.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadofdd.innerText = `
FDD (Feature Driven Development)

O Feature Driven Development (FDD), ou Desenvolvimento Orientado a Funcionalidades, é uma forma ágil de criar software que foca em entregar valor real ao cliente. Em vez de tentar construir tudo de uma vez, o projeto é dividido em pequenas funcionalidades que são desenvolvidas em ciclos curtos.

Essa forma de trabalhar ajuda a acompanhar o progresso, encontrar problemas mais cedo e evita confusão e retrabalho, o que é ótimo para projetos grandes e demorados.
No geral, o FDD valoriza uma boa organização do código, papéis bem definidos dentro da equipe (como programadores responsáveis por partes específicas do sistema) e uma estrutura clara desde o início do projeto. Mesmo sendo uma metodologia ágil, o FDD traz um pouco mais de planejamento e estrutura, o que o torna uma boa escolha quando o projeto é mais complexo.

Componentes humanos envolvidos:
No FDD, existem papéis bem definidos que ajudam a organizar o trabalho. O Chief Architect é quem cria a arquitetura do sistema, garantindo que tudo tenha uma base sólida. O Project Manager cuida do planejamento, prazos e coordenação geral da equipe. O Development Manager supervisiona os desenvolvedores, enquanto o Chief Programmer lidera tecnicamente o desenvolvimento das funcionalidades. Já os Class Owners são os responsáveis por desenvolver e manter partes específicas do código. Por fim, os Domain Experts são especialistas do negócio que ajudam a equipe a entender as necessidades e garantir que as funcionalidades estejam alinhadas com os objetivos do cliente.

Fases do processo:
O desenvolvimento começa com a criação de um modelo geral que apresenta a visão técnica e organizacional do sistema. Em seguida, é feita a lista de funcionalidades, que são pequenas partes do sistema descritas em termos de valor para o usuário. Depois, cada funcionalidade é planejada, com definição de prioridades e recursos. O passo seguinte é o projeto detalhado da funcionalidade, onde se define exatamente como será implementada. Por fim, ocorre a construção, que inclui codificação e testes, garantindo que cada funcionalidade esteja pronta e integrada ao sistema.

Contextualização geral:
O FDD é uma metodologia ágil que traz uma estrutura maior em comparação com outras abordagens, o que ajuda especialmente em projetos grandes e complexos. Ele combina a agilidade das entregas rápidas com um planejamento detalhado, permitindo que o progresso seja facilmente monitorado e que problemas sejam detectados cedo. O foco em funcionalidades específicas ajuda a entregar valor constante ao cliente, evitando que o projeto fique desorganizado ou com retrabalho.

Vantagens e desvantagens:
Entre as vantagens do FDD estão as entregas rápidas e frequentes, o acompanhamento claro do progresso e a boa escalabilidade para equipes maiores e projetos complexos. Por outro lado, a metodologia é menos flexível para mudanças durante o desenvolvimento, exige um planejamento mais detalhado desde o início e não é tão adequada para projetos pequenos ou muito simples, onde esse nível de estrutura pode ser exagerado.
`;
    }
}

function kanban() {
    const estaVazio = resultadokanban.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadokanban.innerText = `Kanban

O Kanban é um método visual para organizar o trabalho, criado na indústria automotiva japonesa. Ele usa um quadro dividido em colunas que mostram as etapas do processo, e cada tarefa é representada por um cartão que vai avançando pelas colunas conforme o trabalho progride. O principal objetivo do Kanban é melhorar a transparência, a eficiência e a colaboração da equipe.

No geral o Kanban ajuda a limitar o número de tarefas em andamento ao mesmo tempo, evitando sobrecarga e facilitando a identificação de gargalos no processo. É uma ferramenta simples, flexível e muito útil para gerenciar fluxos de trabalho de qualquer tamanho.


Componentes humanos envolvidos: 
No Kanban, não há papéis fixos ou rígidos como em outras metodologias. A equipe toda colabora para gerenciar o fluxo de trabalho. Cada membro pode mover os cartões/tarefas no quadro conforme avança o trabalho. O foco está na comunicação aberta e na responsabilidade compartilhada para manter o fluxo eficiente.

Fases do processo: 
O Kanban funciona com um quadro dividido em colunas que representam etapas do processo, como “A Fazer”, “Em Progresso” e “Concluído”. As tarefas começam em uma coluna e, à medida que avançam, os cartões são movidos para a próxima etapa. O processo é contínuo, sem ciclos fixos, e o objetivo é sempre manter o fluxo constante, identificando e resolvendo possíveis bloqueios.

Contextualização geral: 
Kanban é uma abordagem simples e visual para organizar e melhorar o trabalho. Ele surgiu na indústria automotiva japonesa e hoje é usado em diversas áreas, não só em software. Por ser flexível e adaptável, funciona bem em equipes que precisam de um controle visual do que está acontecendo e querem evitar sobrecarga, melhorando a colaboração.

Vantagens e desvantagens: 
As principais vantagens do Kanban são sua simplicidade, visualização clara do trabalho e flexibilidade para mudanças. Ele ajuda a evitar acúmulo de tarefas e melhora a comunicação da equipe. Entre as desvantagens, pode faltar estrutura para equipes que precisam de planejamento rigoroso, e sem disciplina o fluxo pode ficar desorganizado ou com tarefas paradas no meio do processo.`;
    }
}

function crystal() {
    const estaVazio = resultadocrystal.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadocrystal.innerText = `Crystal

O Crystal é uma família de metodologias ágeis criada por Alistair Cockburn. Ele valoriza mais as pessoas, a comunicação e a adaptação do que processos rígidos e ferramentas. O objetivo principal é entregar software funcional de forma rápida e contínua, ajustando o processo conforme o tamanho e a criticidade do projeto.

No geral, o Crystal busca ser simples e flexível, incentivando a comunicação direta e reuniões frequentes. Ele se adapta ao contexto da equipe, variando em práticas e intensidade de documentação dependendo do tipo de projeto.

Componentes humanos envolvidos:
No Crystal, não há papéis fixos e universais. A estrutura muda de acordo com o tamanho da equipe e o nível de risco do projeto. A colaboração é constante, e a comunicação face a face é altamente valorizada para evitar mal-entendidos e acelerar o desenvolvimento.

Fases do processo:
O Crystal não segue fases rígidas, mas costuma incluir planejamento inicial, ciclos curtos de desenvolvimento com entregas frequentes, revisões do produto e reuniões de reflexão para ajustes. O processo é iterativo e adaptado ao projeto em questão.

Contextualização geral:
O Crystal é uma metodologia leve e adaptável, composta por diferentes variantes (Crystal Clear, Crystal Yellow, Crystal Orange etc.), cada uma adequada a equipes de tamanhos e contextos diferentes. A ideia central é que não existe um único processo ideal para todos os projetos: o método deve se ajustar às pessoas e à situação.

Vantagens e desvantagens:
As vantagens do Crystal são sua flexibilidade, foco em comunicação, entregas rápidas e adaptação ao tamanho e criticidade do projeto. Entre as desvantagens, está a falta de estrutura rígida, que pode causar insegurança em equipes acostumadas a processos mais detalhados, além de ser menos indicado para projetos muito grandes e de alta criticidade sem adaptações extras.`;
    }
}

function msf() {
    const estaVazio = resultadomsf.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadomsf.innerText = `MSF (Microsoft Solutions Framework)*

O MSF é uma metodologia de desenvolvimento criada pela Microsoft, voltada para gerenciar projetos de software e tecnologia. Ele reúne boas práticas, modelos de processos e orientações que ajudam equipes a planejar, construir e entregar soluções com qualidade. O objetivo principal do MSF é reduzir riscos, melhorar a comunicação entre os envolvidos e garantir que os projetos sejam entregues dentro do prazo e do orçamento.

No geral, o MSF foca na flexibilidade e na adaptação a diferentes tipos de projetos, permitindo que as equipes escolham os modelos e práticas que mais se encaixam em sua realidade. É um framework que não impõe um processo rígido, mas fornece ferramentas e princípios para organizar o trabalho de forma estruturada e eficiente.


Componentes humanos envolvidos:
No MSF, existem papéis bem definidos que ajudam a distribuir as responsabilidades. Entre eles estão: Gerente de Programa, responsável pelo planejamento; Desenvolvedores, que constroem a solução; Testadores, que garantem a qualidade; Usuários/Clientes, que fornecem os requisitos; e outros papéis que podem variar conforme o projeto. A ideia é ter uma equipe multifuncional que colabore para atingir o mesmo objetivo.

Fases do processo:
O MSF é dividido em fases que representam o ciclo de vida do projeto. As principais são: Visão (definir objetivos e escopo), Planejamento (organizar recursos e tarefas), Desenvolvimento (construção do sistema), Estabilização (testes e ajustes finais) e Implantação (entrega ao cliente). Essas fases ajudam a manter o projeto organizado e a reduzir riscos em cada etapa.

Contextualização geral:
O MSF surgiu na Microsoft como uma forma de organizar grandes projetos de software, mas hoje pode ser aplicado em diferentes contextos de TI. Por ser um framework flexível, ele pode ser adaptado para projetos menores ou maiores, dependendo da necessidade. O foco principal é sempre garantir qualidade, alinhamento com os objetivos do cliente e entrega eficiente.

Vantagens e desvantagens:
As principais vantagens do MSF são sua flexibilidade, o foco na redução de riscos e a clareza de papéis dentro da equipe, o que ajuda a evitar conflitos e falhas de comunicação. Ele também oferece uma visão estruturada do projeto, sem ser tão engessado. Já entre as desvantagens, pode ser considerado complexo para equipes pequenas ou iniciantes, e exige uma boa organização para que todos os papéis e fases sejam cumpridos corretamente.`;
    }
}
function nome() {
    const estaVazio = resultadonome.innerText === "";
    limparResultados();
    if (estaVazio) {
        resultadonome.innerText = `João Vitor Reffatti - RA: 60006231
        Emanuelle Ditz - RA: 60008902
        Pedro Coutinho - RA: 60006242`;
    }
}

//botões

btXp.onclick = function(){
    extreme();
}
btFdd.onclick = function(){
    feature();
}
btKanban.onclick = function(){
    kanban();
}
btCrystal.onclick = function(){
    crystal();
}
btMsf.onclick = function(){
    msf();
}
btNome.onclick = function(){
    nome();
}