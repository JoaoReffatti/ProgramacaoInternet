let InputAno = document.querySelector("#Ano");
let InputValor = document.querySelector("#Valor");
let btImposto = document.querySelector("#btImposto");
let ResultadoImposto = document.querySelector("#ResultadoImposto");

function calcularImposto() {
    let Ano = Number(InputAno.value);
    let Valor = Number(InputValor.value);
       
    if (Ano > 0 && Valor > 0) {
        let taxa = (Ano < 1990) ? 0.01 : 0.015;
        let imposto = Valor * taxa;

        ResultadoImposto.innerHTML = `Ano: ${Ano}<br>
        Valor do carro: R$ ${Valor}<br>
        Taxa aplicada: ${taxa * 100}%<br>
        <strong>Imposto a pagar: R$ ${imposto}</strong>`;
    } else {
        ResultadoImposto.innerHTML = "Por favor, informe um ano e valor válidos.";

    }
}

btImposto.onclick = function () {
    calcularImposto();
};