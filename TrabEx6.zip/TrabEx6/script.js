let inputCodigo = document.querySelector("#codigo");
let inputQuantidade = document.querySelector("#quantidade");
let btLanchonete = document.querySelector("#btLanchonete");
let resultadoLanchonete = document.querySelector("#resultadoLanchonete");

function calcularTotal() {
    let codigo = Number(inputCodigo.value);
    let quantidade = Number(inputQuantidade.value);
    let preco = 0;
    let produto = "";

    if (quantidade <= 0 || !codigo) {
        resultadoLanchonete.innerHTML = "Por favor, preencha os dados corretamente.";
        return;
    }

    switch (codigo) {
        case 1:
            preco = 11.00;
            produto = "Cachorro Quente";
            break;
        case 2:
            preco = 8.50;
            produto = "Bauru";
            break;
        case 3:
            preco = 8.00;
            produto = "Misto Quente";
            break;
        case 4:
            preco = 9.00;
            produto = "Hambúrguer";
            break;
        case 5:
            preco = 10.00;
            produto = "Cheeseburger";
            break;
        case 6:
            preco = 4.50;
            produto = "Refrigerante";
            break;
        default:
            resultadoLanchonete.innerHTML = "Código inválido.";
            return;
    }

    let total = preco * quantidade;

    resultadoLanchonete.innerHTML = `Produto: ${produto}<br>
                           Quantidade: ${quantidade}<br>
                           Total a pagar: R$ ${total.toFixed(2).replace('.', ',')}`;
}

btLanchonete.onclick = calcularTotal;