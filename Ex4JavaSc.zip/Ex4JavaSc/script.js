let Inputnum1 = document.querySelector("#num1");
let Inputnum2 = document.querySelector("#num2");
let Inputnum3 = document.querySelector("#num3");
let btMedia = document.querySelector("#btMedia");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularMedia(){
    let num1 = Number(Inputnum1.value);
    let num2 = Number(Inputnum2.value);
    let num3 = Number(Inputnum3.value);
    let mediaAritmetica = (num1 + num2 + num3) / 3;
    let mediaPonderada = ((num1 * 3) + (num2 * 2) + (num3 * 5)) / (3 + 2 + 5);
    let somaMedias = mediaAritmetica + mediaPonderada;
    let mediaDasMedias = somaMedias / 2;

    h3Resultado.textContent = 
    "Media Aritmetica: " + mediaAritmetica.toFixed(2) + "\n" +
    "Media Ponderada:" + mediaPonderada.toFixed(2) + "\n" +
    "Soma  das Medias:" + somaMedias.toFixed(2) + "\n" +
    "Media das Medias:" + mediaDasMedias.toFixed(2);
}
btMedia.onclick = function(){
    CalcularMedia();
}