let selectNivel = document.querySelector("#nivel");
let inputHoras = document.querySelector("#horas");
let btCalcularProf = document.querySelector("#btCalcularProf");
let resultadoProf = document.querySelector("#resultadoProf");

function calcularSalario() {
    let nivel = selectNivel.value;
    let horas = Number(inputHoras.value);
    let valorHora = 0;

    if (!nivel || horas <= 0) {
        resultadoProf.innerHTML = "Por favor, preencha os dados corretamente.";
        return;
    }

    switch (nivel) {
        case "1":
            valorHora = 12.00;
            break;
        case "2":
            valorHora = 17.00;
            break;
        case "3":
            valorHora = 25.00;
            break;
        default:
            resultadoProf.innerHTML = "Nível inválido.";
            return;
    }

    let salario = valorHora * horas * 4.5;

    resultadoProf.innerHTML = `
        Nível: ${nivel}<br>
        Valor hora/aula: R$ ${valorHora.toFixed(2).replace('.', ',')}<br>
        Total de horas/semana: ${horas}<br>
        Salário mensal: R$ ${salario.toFixed(2).replace('.', ',')}
    `;
}

btCalcularProf.onclick = calcularSalario;