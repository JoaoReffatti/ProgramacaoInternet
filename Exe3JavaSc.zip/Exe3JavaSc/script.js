let InputSaldo = document.querySelector("#Saldo");

let btReajustar = document.querySelector("#btReajustar");
let h3Resultado = document.querySelector("#h3Resultado");

function ReajustarSaldo(){

    let Saldo = Number(InputSaldo.value);
    
    let SaldoReajustado = Saldo + (Saldo * 0.01);

    h3Resultado.textContent = Saldo + (Saldo * 0.01);
}
btReajustar.onclick = function(){
    ReajustarSaldo();
}