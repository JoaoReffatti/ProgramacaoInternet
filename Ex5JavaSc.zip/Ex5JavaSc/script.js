let Inputcotacao = document.querySelector("#cotacao");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

btCalcular.onclick = function(){
    let valor = Number(Inputcotacao.value);

    if (isNaN(valor) || valor <= 0){
        h3Resultado.textContent = "Digite uma cotação válida!";
        return;
    }

    let valor1 = (valor * 1.01).toFixed(2);
    let valor2 = (valor * 1.02).toFixed(2);
    let valor5 = (valor * 1.05).toFixed(2);
    let valor10 = (valor * 1.10).toFixed(2);

    h3Resultado.innerHTML = 
    "Se subir 1%: R$ " + valor1 + "<br>" + 
    "Se subir 2%: R$ " + valor2 + "<br>" + 
    "Se subir 5%: R$ " + valor5 + "<br>" + 
    "Se subir 10%: R$ " + valor10;
}