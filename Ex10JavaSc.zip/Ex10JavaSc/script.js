let Inputcavalos = document.querySelector("#cavalos");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");


function calcularFerradura(){
    let cavalos = Number(Inputcavalos.value);
    let ferraduras = cavalos * 4

    Resultado.innerHTML = "Você precisara de: " + ferraduras + " Ferraduras";
}
btCalcular.onclick = function(){
     calcularFerradura();
}