let Inputsabor1 = document.querySelector("#sabor1");
let Inputsabor2 = document.querySelector("#sabor2");
let Inputsabor3 = document.querySelector("#sabor3");
let Inputsabor4 = document.querySelector("#sabor4");
let Inputrefri = document.querySelector("#refri");
let btFzpedido = document.querySelector("#btFzpedido");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularPedido(){
    let sabor1 = Inputsabor1.value;
    let sabor2 = Inputsabor2.value;
    let sabor3 = Inputsabor3.value;
    let sabor4 = Inputsabor4.value;
    let refri = Number(Inputrefri.value);

    let precoPizza = 12.00;
    let precoRefri = 7.00;

    let total = (4 * precoPizza) + (refri * precoRefri);

    
    h3Resultado.innerHTML =
   "Sabores escolhidos:" + "<br>" +
    " - " + sabor1 + "<br>" +
    " - " + sabor2 + "<br>" +
    " - " + sabor3 + "<br>" +
    " - " + sabor4 + "<br>" +
    "Quantidade de refrigerantes: " + refri + "<br>" +
    "Valor total: R$ " + total.toFixed(2);
} 

btFzpedido.onclick = function(){
    calcularPedido();
}