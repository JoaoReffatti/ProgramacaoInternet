let InputPaes = document.querySelector("#Paes");
let InputBroas = document.querySelector("#Broas");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function CalcularRenda(){
    let Paes = Number(InputPaes.value);
    let Broas = Number(InputBroas.value);

    let valorPaes = Paes * 0.12;
    let valorBroas = Broas * 1.50;
    let total = Broas + Paes;
    let poupanca = total * 0.10;

    resultado.innerHTML =
    "Total arrecadado: R$" + total + "<br>" + 
    "Valor para guardar na poupança (10%): R$ " + poupanca;

}
btCalcular.onclick = function(){
    CalcularRenda();

}