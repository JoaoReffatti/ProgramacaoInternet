let Inputnum1 = document.querySelector("#num1");
let Inputnum2 = document.querySelector("#num2");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularOperacoes(){
    let num1 = Number(Inputnum1.value);
    let num2 = Number(Inputnum2.value);

    let soma = num1 + num2;
    let subtracao = num1 - num2;
    let multiplicacao = num1 * num2;
    let divisao = num2 !== 0 ? (num1 / num2).toFixed(2) : "Divisão por zero";
    
    h3Resultado.innerHTML =
    "Soma: " + soma + "<br>" +
    "Subtração: " + subtracao + "<br>" +
    "Multiplicação: " + multiplicacao + "<br>" +
    "Divisão: " + divisao;
}

btCalcular.onclick = function(){
    calcularOperacoes();
};