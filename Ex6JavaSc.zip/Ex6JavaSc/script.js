let Inputpessoas = document.querySelector("#pessoas");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

btCalcular.onclick = function(){
    let pessoas = Number(Inputpessoas.value);

    if (isNaN(pessoas) || pessoas <= 0){
        h3Resultado.textContent = "Digite um número válido de pessoas!";
        return;
    }

    let ovos = pessoas * 2;
    let queijo = pessoas * 50;
   

    h3Resultado.innerHTML = 
    "Você vai precisar de:" + "<br>" +
    ovos + " Ovos <br> E" + "<br>" +
    queijo + " Gramas de Queijo";
}