import java.util.Scanner;

public class exec08{

    public static void main(String[] args){
        Scanner s = new Scanner(System.in);

        Double num1;
        Double num2;
        Double consumo;
        Double media;


        System.out.println("Informe o que foi gasto dia 1: ");
        num1 = s.nextDouble();
        System.out.println("Informe o que foi gasto até dia 30: ");
        num2= s.nextDouble();

        consumo = num2 - num1;
        media = consumo / 30;


        System.out.println("O consumo foi de: " + consumo);
        System.out.println("A media é de: " + media);


    }
}
