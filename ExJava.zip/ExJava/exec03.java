import java.util.Scanner;

public class exec03{
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        String resultado="Numero PAR";
        int num;

        System.out.println("Informe o primeiro numero: ");
        num = s.nextInt();

        if (num % 2 !=0){
            resultado = "Numero IMPAR!";
        }
        System.out.println("\n Exemplo John: " + resultado);
        if(num % 2 != 0){
            resultado = "Numero IMPAR";
        }

    }
}