public class execSwitch {
    public static void main(String[] args){
        int opcao;
        String resultado;
        opcao = 3;

        switch(opcao){
            case 1:
            resultado = "opcao 1";
            break;
            case 2:
            resultado = "opcao 2";
            break;
            case 3:
            resultado = "opcao 3";
            break;
            case 4:
            resultado = "opcao 4";
            break;
            case 5:
            resultado = "opcao 5";
            break;
            default:
            resultado = "opcao invalida";
            break;

        }
        System.out.println("Opcao escolhida: " + resultado);
    }
    
}
