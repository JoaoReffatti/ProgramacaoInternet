let inputPreco = document.querySelector("#preco");
let selectCondicao = document.querySelector("#condicao");
let btCalcularVendas = document.querySelector("#btCalcularVendas");
let resultadoVendas = document.querySelector("#resultadoVendas");

function calcularVenda() {
    let preco = Number(inputPreco.value);
    let condicao = selectCondicao.value;
    let total = 0;
    let descricao = "";

    if (preco <= 0 || !condicao) {
        resultadoVendas.innerHTML = "Por favor, informe o preço e a condição de pagamento.";
        return;
    }

    switch (condicao) {
        case "a":
            total = preco * 0.90;
            descricao = "À vista em dinheiro ou cheque (10% de desconto)";
            break;
        case "b":
            total = preco * 0.85;
            descricao = "À vista no cartão de crédito (15% de desconto)";
            break;
        case "c":
            total = preco;
            descricao = "Em duas vezes (sem juros)";
            break;
        case "d":
            total = preco * 1.10;
            descricao = "Em duas vezes (com 10% de juros)";
            break;
        default:
            resultadoVendas.innerHTML = "Condição de pagamento inválida.";
            return;
    }

    resultadoVendas.innerHTML = `
        Condição: ${descricao}<br>
        Valor final: R$ ${total.toFixed(2).replace('.', ',')}
    `;
}

btCalcularVendas.onclick = calcularVenda;