let inputPago = document.querySelector("#valorPago");
let inputPreco = document.querySelector("#precoProduto");
let btTroco = document.querySelector("#btSomarTroco");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularTroco(){

    let Pago = Number(inputPago.value);
    let Preco = Number(inputPreco.value);
    let Troco = Pago - Preco

    h3Resultado.textContent = (Pago - Preco);
}
btTroco.onclick = function(){
    calcularTroco();
}